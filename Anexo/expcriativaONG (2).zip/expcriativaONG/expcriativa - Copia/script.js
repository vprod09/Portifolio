function togglePassword() {
    const passwordInput = document.getElementById("password");
    if (passwordInput.type === "password") {
      passwordInput.type = "text";
    } else {
      passwordInput.type = "password";
    }
  }
  
  
  // Função para mostrar ou esconder a senha
  document.getElementById('togglePassword').addEventListener('click', function () {
    var passwordField = document.getElementById('password');
    var confirmPasswordField = document.getElementById('confirmPassword');
    var passwordFieldType = passwordField.type === 'password' ? 'text' : 'password';
    passwordField.type = passwordFieldType;
    confirmPasswordField.type = passwordFieldType;
  
    // Atualiza o texto do botão
    this.textContent = passwordFieldType === 'password' ? 'Mostrar Senha' : 'Esconder Senha';
  });
  
  // Função para validar se as senhas coincidem
  document.getElementById('cadastroForm').addEventListener('submit', function (e) {
    var password = document.getElementById('password').value;
    var confirmPassword = document.getElementById('confirmPassword').value;
    if (password !== confirmPassword) {
        alert('As senhas não coincidem.');
        e.preventDefault(); // Impede o envio do formulário
    }
  });
  
  function handleSubmit(event) {
    event.preventDefault(); // Impede o envio padrão do formulário
    const isChecked = document.getElementById('role').checked;
    if (isChecked) {
        window.location.href = 'admpag.html'; // Redireciona para a página de administradora
    } else {
        window.location.href = 'Mapa.html'; // Redireciona para a página de usuário
    }
  }